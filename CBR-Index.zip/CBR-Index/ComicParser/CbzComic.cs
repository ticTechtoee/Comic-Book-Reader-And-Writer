using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Zip.Compression.Streams;

namespace Baileysoft.Utils.ComicParser
{
    public class CbzComic : IComic
    {
         public CbzComic(string path)
        {
            ComicFile = new FileInfo(path);
            GenerateCover();
        }

        private void GenerateCover()
        {
            this.ErrorMessage = string.Empty;
            
            using (ZipFile zFile = new ZipFile(File.OpenRead(FilePath)))
            {
                PageCount = (int)zFile.Count;
            }

            using (ZipInputStream s = new ZipInputStream(File.OpenRead(FilePath)))
            {
                ZipEntry theEntry;
                while ((theEntry = s.GetNextEntry()) != null)
                {
                    
                    string directoryName = Path.GetDirectoryName(theEntry.Name);
                    string fileName = Path.GetFileName(theEntry.Name);

                    // create directory if the archive has a folder at root
                    if (directoryName.Length > 0)
                    {
                        string fDirectory = Path.GetTempPath() + directoryName;
                        
                        //We need to delete the directory is it's already there so we get the first entry
                        if (Directory.Exists(fDirectory))
                        {
                            Directory.Delete(fDirectory, true);
                        }
                        Directory.CreateDirectory(fDirectory);
                    }

                    string fullPath = Path.GetTempPath() + theEntry.Name;

                    if (fileName != String.Empty && !File.Exists(fullPath))
                    {
                        using (FileStream streamWriter = File.Create(fullPath))
                        {
                            int size = 2048;
                            byte[] data = new byte[2048];
                            while (true)
                            {
                                size = s.Read(data, 0, data.Length);
                                if (size > 0)
                                {
                                    streamWriter.Write(data, 0, size);
                                }
                                else
                                {
                                    break;
                                }
                            }
                            CoverPath = fullPath;
                            return; //Just return the 1st entry in the archive
                        }
                    }
                }
            }
        }
    }
}
