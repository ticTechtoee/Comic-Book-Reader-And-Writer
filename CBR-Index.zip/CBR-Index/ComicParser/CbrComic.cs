using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Baileysoft.Utils.ComicParser
{
    public class CbrComic : IComic 
    {
        public CbrComic(string path)
        {
            ComicFile = new FileInfo(path);
            GenerateCover();
        }

        private void GenerateCover()
        {
            this.ErrorMessage = string.Empty;
            string path = string.Empty;
            Chilkat.Rar rar = new Chilkat.Rar();
            bool success = rar.Open(FilePath);
            PageCount = (int)rar.NumEntries;

            path = Path.GetTempPath();

            //Chilkat.RarEntry entry = rar.GetEntryByName(FilePath);
            if (success)
            {
                Chilkat.RarEntry entry = rar.GetEntryByIndex(0);
                if (entry.IsDirectory)
                {
                    entry = rar.GetEntryByIndex(1);
                    entry.Unrar(path);
                }
                else
                {
                    entry.Unrar(path);
                }

                FileInfo FI = new FileInfo(string.Format("{0}\\{1}", path, entry.Filename));
                CoverPath = FI.FullName;
            }
            else
            {
                this.ErrorMessage = "There was an Error: " + rar.LastErrorText;
            }
        }
    }
}
