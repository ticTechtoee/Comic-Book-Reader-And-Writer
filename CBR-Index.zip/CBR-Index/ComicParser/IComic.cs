using System;
using System.IO;
using System.Collections.Generic;
using System.Text;

namespace Baileysoft.Utils.ComicParser
{
    public abstract class IComic
    {
        private string _coverPath;
        private string _errorMessage;
        private int _pageCount;
        private FileInfo _file;

        /// <summary>
        /// 
        /// </summary>
        public String FileName
        {
            get
            {
                return _file.Name;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public String FilePath
        {
            get
            {
                return _file.FullName;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public String CoverPath
        {
            get
            {
                return _coverPath;
            }
            set
            {
                _coverPath = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public long FileSize
        {
            get
            {
                return (long)BytesToMegaBytes(_file.Length);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public int PageCount
        {
            get
            {
                return _pageCount;
            }
            set
            {
                _pageCount = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public FileInfo ComicFile
        {
            set
            {
                _file = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public String ErrorMessage
        {
            get
            {
                return _errorMessage;
            }
            set
            {
                _errorMessage = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public double BytesToMegaBytes(long bytes)
        {
            double Bytes = Convert.ToDouble(bytes);
            double usedBW = Bytes / (1024 * 1024);
            return usedBW = Math.Round(usedBW, 3);
        }
    }
}
