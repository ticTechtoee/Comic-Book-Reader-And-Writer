using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Baileysoft.Utils.ComicParser;

namespace CBR_Index
{
    public partial class Form1 : Form
    {
        private IComic myComic;
        private string scanPath;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PopulateFilesListBox();
        }

        private void PopulateFilesListBox()
        {
            label1.Text = ConfigurationManager.AppSettings["banner"];
            scanPath = ConfigurationManager.AppSettings["scan"];

            if (scanPath == "")
                scanPath = Environment.CurrentDirectory;

            DirectoryInfo directory = new DirectoryInfo(scanPath);
            foreach (FileInfo file in directory.GetFiles("*.cbr"))
                lbFiles.Items.Add(file.Name);

            foreach (FileInfo file in directory.GetFiles("*.cbz"))
                lbFiles.Items.Add(file.Name);

            lbFiles.SelectedIndex = 0;
        }

       
        private void GeneratePreview()
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.ImageLocation = GetZeroImageFromArchive();
        }

        private string GetZeroImageFromArchive()
        {
            string selected = lbFiles.SelectedItem.ToString().ToLower();
            if (selected.IndexOf(".cbr") > -1)
            {
                myComic = new CbrComic(string.Format("{0}\\{1}",
                scanPath, lbFiles.SelectedItem.ToString()));
            }

            if (selected.IndexOf(".cbz") > -1)
            {
                myComic = new CbzComic(string.Format("{0}\\{1}",
                scanPath, lbFiles.SelectedItem.ToString()));
            }
            
            textBox1.Text = string.Format("{0}\r\nSize: {1}MB\r\nPages: {2}", 
                myComic.FileName, myComic.FileSize, myComic.PageCount);

            if (myComic.ErrorMessage != string.Empty)
            {
                MessageBox.Show(myComic.ErrorMessage);
            }
             
            return myComic.CoverPath;
        }

        private void lbFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            GeneratePreview();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(myComic.FilePath);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}