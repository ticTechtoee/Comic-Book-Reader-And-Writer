namespace SharpCompress.Compressors.Rar.PPM
{
    internal enum BlockTypes
    {
        BLOCK_LZ = 0,
        BLOCK_PPM = 1
    }
}