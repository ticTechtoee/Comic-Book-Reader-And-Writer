namespace SharpCompress.Compressors.Rar.Decode
{
    internal class MultDecode : Decode
    {
        internal MultDecode()
            : base(new int[Compress.MC20])
        {
        }
    }
}