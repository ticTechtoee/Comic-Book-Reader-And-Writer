﻿namespace SharpCompress.Compressors.PPMd
{
    public enum PpmdVersion
    {
        H,
        H7z,
        I1
    }
}